from fpdf import FPDF


class PDF(FPDF):
    def add_name_to_shirt(self, name):

        # Setting font: helvetica bold 15
        self.set_font("helvetica", "B", 50)
        # Moving cursor to the right:
        # Printing title:
        self.cell(0, 60, "CS50 Shirtificate", ln=True, align="C")

        self.image("shirtificate.png", w=self.epw)
        self.set_font_size(30)

        self.set_text_color(255,255,255)

        self.text(x=48, y=140, text=f"{name} took CS50")



    def save(self, filename):
        self.output(filename)



# Instantiation of inherited class

#pdf.set_font("Times", size=12)
name = input("Name: ")
pdf = PDF()
pdf.add_page()
pdf.add_name_to_shirt(name)
pdf.save("shirtificate.pdf")

