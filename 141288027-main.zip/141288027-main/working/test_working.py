from working import convert
import pytest

def test_convert():
    assert convert("9:00 AM to 3:00 PM") == "09:00 to 15:00"
    assert convert("12:00 AM to 3:00 PM") == "00:00 to 15:00"
    assert convert("9:00 PM to 12:00 AM") == "21:00 to 00:00"
    assert convert("5 PM to 9 AM") == "17:00 to 09:00"
def test_outofrange():
    with pytest.raises(ValueError):
        convert("9:62 AM to 5:02 PM")
def test_noto():
    with pytest.raises(ValueError):
        convert("9 AM - 5 PM")

