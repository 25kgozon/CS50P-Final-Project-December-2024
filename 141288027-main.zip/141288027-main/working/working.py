import re
import sys
'''
This program takes in two times: begin and end, and converts it to military time
Example inputs with output:
9:00 AM to 5:00 PM = 09:00 to 17:00
9 AM to 5 PM
9:00 AM to 5 PM
9 AM to 5:00 PM
'''


def main():
    print(convert(input("Hours: ")))


def convert(s):
    try:
        #splits input into "begin and end" times ex. 9:00 AM to 3:00 PM = [9:00 AM], [3:00 PM]
        time1, time2 = s.split(" to ")
        #checks for : to split into hr/min for begin time
        if ":" in time1:
            #makes sure input isnt 12:00 PM
            if "12:00 PM" not in time1:
                # ex. 9:30 becomes [9], [30]
                hours1, minutes1 = time1.split(":")
                hours = re.findall(r'\d+', hours1)
                minutes = re.findall(r'\d+', minutes1)
                if hours:
                    hours = int(hours[0])
                    if hours < 12:
                        if "PM" in time1:
                            #makes the conversion from 9 PM to 9 + 12 = 21 military time
                            hours = hours + 12
                    else:
                        #if hours do equal 12, it means midnight, so hour 0 (00:00)
                        hours = 0
                if minutes:
                    minutes = int(minutes[0])
                    #makes sure input is doesnt excede 60 min in an hour ex 9:62 not accepted
                    if minutes < 60:
                        military_time = f"{int(hours):02}:{minutes:02}"
                    else:
                        raise ValueError
            else:
                #sets value to 12 if input is 12 PM
                military_time = "12:00"
        #if only hours are provided, such as 9 AM instead of 9:00 AM
        else:
            if "12 PM" not in time1:
                if "AM" in time1:
                    hours1, minutes1 = time1.split(" AM")
                if "PM" in time1:
                    hours1, minutes1 = time1.split(" PM")
                hours = re.findall(r'\d+', hours1)
                minutes = re.findall(r'\d+', minutes1)
                hours = int(hours[0])
                if hours < 12:
                    if "PM" in time1:
                        #sets default value of 00 minutes
                        minutes = "00"
                        hours = hours + 12
                    else:
                        hours = hours
                        minutes = "00"
                else:
                    hours = time1.replace(" AM","")
                    minutes = "00"
                    hours = 0
                military_time = f"{int(hours):02}:{minutes}"
            else:
                military_time = "12:00"
        #program now analyzes the end time (refer to comments above for reference)
        if ":" in time2:
            if "12:00 PM" not in time2:
                hours2, minutes2 = time2.split(":")
                hours = re.findall(r'\d+', hours2)
                minutes = re.findall(r'\d+', minutes2)
                if hours:
                    hours = int(hours[0])
                    if hours < 12:
                        if "PM" in time2:
                            hours = hours + 12
                    else:
                        hours = 0
                if minutes:
                    minutes = int(minutes[0])
                    if minutes < 60:
                        military_time2 = f"{int(hours):02}:{minutes:02}"
                    else:
                        raise ValueError
                else:
                    hours = time2.replace(" PM","")
                    minutes = "00"
                    military_time2 = f"{int(hours):02}:{minutes}"
            else:
                military_time2 = "12:00"
        else:
            if "12 PM" not in time2:
                if "AM" in time2:
                    hours2, minutes2 = time2.split(" AM")
                if "PM" in time2:
                    hours2, minutes2 = time2.split(" PM")
                hours = re.findall(r'\d+', hours2)
                minutes = re.findall(r'\d+', minutes2)
                hours = int(hours[0])
                if hours < 12:
                    if "PM" in time2:
                        minutes = "00"
                        hours = hours + 12
                    else:
                        hours = hours
                        minutes = "00"
                else:
                    hours = time2.replace(" AM","")
                    minutes = "00"
                    hours = 0
                military_time2 = f"{int(hours):02}:{minutes}"
            else:
                military_time2 = "12:00"

        return f"{military_time} to {military_time2}"
        #return f"{int(hours):02}"
        #return military_time2
        #return military_time
        #return time1
        #return hours





    except ValueError:
        raise




...


if __name__ == "__main__":
    main()
