import re
import sys


def main():
    print(parse(input("HTML: ")))


def parse(s):
    #recognize "src="
    #remove embed
    #for char in s:
        if "src" in s and "youtube.com" in s:
            left, right = s.split("src=\"")
            left.replace(left, " ")
            if "\"" in right:
                url, remaining = right.split("\"")
                url.replace(remaining, " ")
                url = url.replace("embed/", "")
                if "youtube.com" in url:
                    url = url.replace("youtube.com", "youtu.be")
                if "http://" in url:
                    url = url.replace("http://", "https://")
                if "www." in url:
                    url = url.replace("www.", "")
                return url


        else:
            return None





if __name__ == "__main__":
    main()
