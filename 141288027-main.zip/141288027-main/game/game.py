import random
flag = False
try:
    while True:
        lvl = input("Level: ")
        if lvl.isalpha() == False:
            if int(lvl) > 0:
                while True:
                    difficulty = random.randint(1, int(lvl))
                    guess = int(input("Guess: "))
                    if guess == difficulty:
                        print("Just right!")
                        flag = True
                        break
                    elif guess < difficulty:
                        print("Too small!")
                    else:
                        print("Too large!")
                if flag:
                    break
        else:
            pass
except TypeError or ValueError:
    pass
