def say_hello(name):
    return "hello " + name




