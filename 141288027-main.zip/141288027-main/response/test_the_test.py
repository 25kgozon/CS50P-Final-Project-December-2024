from test import say_hello as hello

def main():
    print(hello(input("What is your name: ")))








if __name__ == "__main__":
    main()
