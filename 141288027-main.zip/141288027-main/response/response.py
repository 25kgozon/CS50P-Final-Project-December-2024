from validator_collection import validators, checkers, errors

def main():
    print(validate(input("What is your email address? ")))

def validate(email):
    is_email_address = checkers.is_email(email)
    if not is_email_address:
        return "Invalid"
    return "Valid"



if __name__ == "__main__":
    main()
