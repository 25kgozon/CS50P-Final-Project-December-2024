from pyfiglet import Figlet
import sys
from random import choice
figlet = Figlet()
fonts = figlet.getFonts()
if len(sys.argv) == 1:
    text = input("Input: ")
    random_font = choice(fonts)
    f = Figlet(font=random_font)
    print(f.renderText(text))
elif len(sys.argv) == 3 and (sys.argv[1] == "-f" or sys.argv[1] == "--f"):
    chosen_font = sys.argv[2]
    if chosen_font not in fonts:
        print("Inavlid usage")
        sys.exit(1)
    text = input("Input: ")
    f = Figlet(font=chosen_font)
    print(f.renderText(text))
else:
    print("Invalid usage")
    sys.exit(1)

