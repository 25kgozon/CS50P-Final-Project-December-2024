c = str(input("Say something "))
print(str.lower(c))