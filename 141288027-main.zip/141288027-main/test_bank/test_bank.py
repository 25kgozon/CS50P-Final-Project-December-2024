from bank import value

def test_value():
    assert value("hello") == 0
    assert value("What's Up") == 100
    assert value("hello how are you") == 0
    assert value("hElLo") == 0
