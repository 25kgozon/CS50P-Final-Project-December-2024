def main():
    greeting = input("Greeting: ")
    print(value(greeting))

def value(greeting):
    greeting_low = greeting.lower()
    no_spaces = greeting_low.replace(" ","")
    if no_spaces.startswith("hello"):
        return 0
    elif greeting_low.startswith("h"):
        return 20
    else:
        return 100



if __name__ == "__main__":
    main()
