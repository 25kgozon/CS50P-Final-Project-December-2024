import re
import sys


def main():
    print(count(input("Text: ").strip()))


def count(s):
    lower_s = s.lower()
    substring_s = "um"
    um = rf'\b{re.escape(substring_s)}\b'
    res= len(re.findall(um, lower_s))

    return res




...


if __name__ == "__main__":
    main()
