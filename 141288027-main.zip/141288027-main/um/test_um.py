from um import count

def test_count():
    assert count("um") == 1
    assert count("Um") == 1
    assert count("um, um, hello, um") == 3
    assert count("mum um gum um") == 2
