from twttr import shorten

def test_a():
    assert shorten("apple") == "ppl"
    assert shorten("APPLE") == "PPL"
    assert shorten("apple1") == "ppl1"
    assert shorten("apple.") == "ppl."



