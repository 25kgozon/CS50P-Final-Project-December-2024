def main():
    twttr = input("Input: ")
    print(f"Output: {shorten(twttr)}")

def shorten(word):
    vowels = ['a','e','i','o','u', 'A','E','I','O','U']

    for letter in word:
        if letter in vowels:
            word = word.replace(letter, "")


if __name__ == "__main__":
    main()
