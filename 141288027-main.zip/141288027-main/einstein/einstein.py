Mass = int(input("m: "))
Energy = Mass * (300000000**2)
print(f"E: {Energy}")
