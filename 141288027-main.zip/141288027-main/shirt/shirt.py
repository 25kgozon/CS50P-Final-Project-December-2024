import sys; import csv; import os
from PIL import Image; from PIL import ImageOps
if len(sys.argv) < 3:
    print("Too few command-line arguments")
    sys.exit(1)
elif len(sys.argv) > 3:
    print("Too many command-line arguments")
    sys.exit(1)
else:
    filename1 = os.path.splitext(sys.argv[1])
    filename2 = os.path.splitext(sys.argv[2])
    if filename1[1] and filename2[1] == " ":
        print("Invalid Input")
        sys.exit(1)
    else:
        if filename1[1] != filename2[1]:
            print("Input and output have different extensions")
            sys.exit(1)
        elif filename1[1] == '.jpg' or filename1[1] == '.jpeg' or filename1[1] == '.png':
            try:
                person = Image.open(sys.argv[1])
                shirt = Image.open('shirt.png')
                size = shirt.size
                resized_person = ImageOps.fit(person, size)
                resized_person.paste(shirt, shirt)
                resized_person.save(sys.argv[2])


            except FileNotFoundError:
                sys.exit(1)
        else:
            print("Invalid input")
            sys.exit(1)


