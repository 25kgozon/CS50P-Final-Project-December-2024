def convert(face):
    face = face.replace(":)","🙂")
    face = face.replace(":(","🙁")
    return face
def main():
    face = input("Say something ")
    face = convert(face)
    print(face)
main()
