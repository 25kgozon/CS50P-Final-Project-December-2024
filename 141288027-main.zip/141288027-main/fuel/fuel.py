while True:
    try:
        fuel = (input("Fraction: "))
        x,y = int(fuel.split("/")[0]), int(fuel.split("/")[1])
        percent = int(round((x/y) * 100))
        if 99 <= percent <= 100:
            print("F")
            break
        elif percent <= 1:
            print("E")
            break
        elif x > y:
            print("Value is over limit")
            continue
    except ValueError:
        pass
    except ZeroDivisionError:
        print("Y can't be 0")
    else:
        print(f"{percent}%")
        break


