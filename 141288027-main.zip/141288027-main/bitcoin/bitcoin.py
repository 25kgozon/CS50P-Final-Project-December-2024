import requests
import sys
import json

if len(sys.argv) == 2:
    try:
        val = float(sys.argv[1])
    except:
        print("Command-line argument is not a number")
        sys.exit(1)
else:
    print("Missing Command-line argument")

try:
    response = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
    r = response.json()
    rate = (r["bpi"]["USD"]["rate_float"])
    price = rate * val
    print(f"${price:,.4f}")
except requests.RequestException:
    sys.exit(1)



