import sys; import csv
if len(sys.argv) < 3:
    print("Too few command-line arguments")
    sys.exit(1)
elif len(sys.argv) > 3:
    print("Too many command-line arguments")
    sys.exit(1)
else:
    try:
        students = []
        with open(sys.argv[1]) as file:
            reader = csv.reader(file)
            next(reader)
            for name, house in reader:
                students.append({"name": name, "house": house})
        with open(sys.argv[-1], "w") as file:
            writer = csv.DictWriter(file, fieldnames=["first", "last", "house"])
            writer.writeheader()
            for student in students:
                first = student["name"].split(",")[-1].lstrip()
                last = student["name"].split(",")[0]
                writer.writerow({"first": first, "last": last, "house": student["house"]})



    except FileNotFoundError:
        print(f"Could not read {sys.argv[-2]}")
        sys.exit(1)



