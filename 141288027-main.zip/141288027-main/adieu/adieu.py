import inflect
p = inflect.engine()
list_of_names = []
try:
    while True:
        name = input("Name: ")
        list_of_names.append(name)
except EOFError:
    msg = p.join(list_of_names)
print(f"\nAdieu, adieu, to {msg}")
