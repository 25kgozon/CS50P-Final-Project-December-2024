prompt = input("Say something ")
a = " "
b = "..."
mod_prompt = prompt.replace(a,b)
print(mod_prompt)