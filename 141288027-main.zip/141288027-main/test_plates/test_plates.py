from plates import is_valid


def test_is_valid():
    assert is_valid("aa1234") == True
    assert is_valid("123456") == False
    assert is_valid("abc12a") == False
    assert is_valid("aa0000") == False
    assert is_valid("a1b2c3") == False
    assert is_valid("1abcd") == False
    assert is_valid("afggshghgsafsghgag") == False
    assert is_valid("123455") == False
