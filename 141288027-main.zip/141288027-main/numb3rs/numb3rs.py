


def main():
    print(validate(input("IPv4 Address: ").strip()))


def validate(ip):
    groups = ip.split(".")
    for group in groups:
            if not group.isdigit() or not (0 <= int(group) <= 255) or (len(groups) != 4):
                return False
    return True



if __name__ == "__main__":
    main()
