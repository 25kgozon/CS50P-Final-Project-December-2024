class Jar:
    def __init__(self, capacity=12):
        if capacity < 0:
            raise ValueError("Capacity cannot be negative")
        self._capacity = capacity
        self._size = 0

    def __str__(self):
        totalCookies = self.size * "🍪"
        return totalCookies

    def deposit(self, n):
        if self.size + n > self.capacity:
            raise ValueError("12 is max capacity")
        self.size += n


    def withdraw(self, n):
        if  n > self.size:
            raise ValueError("12 is max capacity")
        self.size -= n


    @property
    def capacity(self):
        return self._capacity

    @property
    def size(self):
        return self._size

    @capacity.setter
    def capacity(self, capacity):
        self._capacity = capacity

    @size.setter
    def size(self, size):
        self._size = size


cookie_jar = Jar()
cookie_jar.deposit(12)
cookie_jar.withdraw(11)
print(cookie_jar)
