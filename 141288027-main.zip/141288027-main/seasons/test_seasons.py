from seasons import num_Min
import pytest

def test_num_min():
    assert num_Min("1999-01-01") == "Thirteen million, five hundred seventy-nine thousand, two hundred minutes"
def test_invalid_input():
    with pytest.raises(SystemExit):
        num_Min("January 1, 1999")
