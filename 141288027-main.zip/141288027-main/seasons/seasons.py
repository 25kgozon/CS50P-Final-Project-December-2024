from datetime import date, datetime
import inflect
import sys


def main():
    print(num_Min(input("Date of birth: ")))



def num_Min(s):
    p = inflect.engine()
    try:
            year, month, day = int(s.split("-")[0]), int(s.split("-")[1]), int(s.split("-")[2])
            today = date.today()
            dob = date(year, month, day)
            duration = today - dob
            duration_in_sec = int(duration.total_seconds())
            duration_in_min = int(duration_in_sec/60)
            minutes = p.number_to_words(duration_in_min, andword = "")
            return f"{minutes.capitalize()} minutes"

    except (ValueError, IndexError):
        sys.exit("Invalid Date")




if __name__ == "__main__":
    main()
