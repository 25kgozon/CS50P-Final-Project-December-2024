import sys
if len(sys.argv) == 1:
    print("Too few command-line arguments")
    sys.exit(1)
elif len(sys.argv) > 2:
    print("Too many command-line arguments")
    sys.exit(1)
else:
    filename = sys.argv[-1]
    if filename[-3:] != ".py":
        print("Not a Python File")
        sys.exit(1)
    else:
        i = 0
        try:
            with open(sys.argv[1]) as file:
                for line in file:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    i += 1
                print(i)

        except:
            FileNotFoundError
            print("File Does Not Exist")
            sys.exit(1)


