    #test


print("i")
print("h")
print("hello")
print("1")
print("1")
                                        #test
