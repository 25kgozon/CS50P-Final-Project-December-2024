#this program accepts user input in month/day/year or month day, year and converts either input to year/month/day
months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]
while True:
    #asks for date (numerical or string)
    date = input("Date: ")
    try:
        #splits input at slashes
        month, day, year = int(date.split("/")[0]), int(date.split("/")[1]), int(date.split("/")[2])
        #makes sure date is valid
        if 1 <= month <= 12 and 1 <= day <= 31:
            break
        else:
            pass
    except:
        try: #(ISSUE WITH THIS)
            #replaces input at comma
            date = date.replace(","," ")
            sep_date = date.split(" ")
            #splits input at spaces of input
            month, day, year = (sep_date.split(" ")),(sep_date.split(" ")),(sep_date.split(" "))
            #if month from input is found in the list
            if month in months:
                #get index of the month from list
                month = months.index(month) + 1
                if 1 <= month <= 12 and 1 <= day <= 31:
                    break
            else:
                pass
        except:
            print()
            pass
#prints date in proper format
print(f"{year}-{month:02}-{day:02}")




