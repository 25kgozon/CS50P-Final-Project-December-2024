import fuel
from fuel import convert, gauge
import pytest

def test_fuel():
    assert convert("2/3") == 67
def test_f():
    assert gauge(99) == "F"
def test_e():
    assert gauge(1) == "E"
def test_num():
    assert gauge(33) == "33%"
def test_zero_div_err():
    with pytest.raises(ZeroDivisionError):
        convert("1/0")
def test_val_err():
    with pytest.raises(ValueError):
        convert("cat/dog")

