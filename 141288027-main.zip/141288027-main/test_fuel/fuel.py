def main():
    fraction = (input("Fraction: "))
    conv_fraction = convert(fraction)
    percent = (gauge(conv_fraction))
    print(percent)

def convert(fraction):
    while True:
        try:
            x, y = int(fraction.split("/")[0]), int(fraction.split("/")[1])
            frac = x / y
            if frac < 1:
                percent = round(frac * 100)
                return percent
            else:
                fraction = int(input("Fraction; "))
                pass
        except (ValueError, ZeroDivisionError):
            raise





def gauge(percentage):
    if 99 <= percentage <= 100:
        return "F"
    elif percentage <= 1:
        return "E"
    else:
        return str(percentage) + "%"




if __name__ == "__main__":
    main()
