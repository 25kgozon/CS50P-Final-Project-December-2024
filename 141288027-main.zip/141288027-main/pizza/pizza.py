import sys
from tabulate import tabulate
if len(sys.argv) == 1:
    print("Too few command-line arguments")
    sys.exit(1)
elif len(sys.argv) > 2:
    print("Too many command-line arguments")
    sys.exit(1)
else:
    filename = sys.argv[-1]
    if filename[-3:] != "csv":
        print("Not a CSV File")
        sys.exit(1)
    else:
        try:
            info = []
            if sys.argv[1] == "regular.csv":
                with open("regular.csv") as file:
                    for line in file:
                        row = line.rstrip().split(",")
                        info.append(row)
                    print(tabulate(info, tablefmt="grid"))

            else:
                with open("sicilian.csv") as file:
                    for line in file:
                        row = line.rstrip().split(",")
                        info.append(row)
                    print(tabulate(info, tablefmt="grid"))

        except:
            FileNotFoundError
            print("File Does Not Exist")
            sys.exit(1)

